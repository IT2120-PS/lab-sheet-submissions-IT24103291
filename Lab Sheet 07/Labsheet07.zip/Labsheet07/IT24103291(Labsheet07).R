setwd("C:\\Users\\U S E R\\OneDrive - Sri Lanka Institute of Information Technology\\2 Year 1 Semester\\PS\\Lab\\LabSheet07")
#Exercise
#Q1
#Uniform Distribution
#min=0,max=40
#p(10<x<25)=(p(x<=25)-p(x<=10))
punif(25,min = 0,max = 40,lower.tail = TRUE)-punif(10,min = 0,max = 40,lower.tail = TRUE)

#Q2
#lemda=0.3333
#x<=2hours
#Exponential Distribution
pexp(2,rate = 0.3333,lower.tail = TRUE)

#Q3
#Normal Distribution

#mean=100,sd=15

#1
#x>130
pnorm(130,mean = 100,sd=15,lower.tail = FALSE)

#2
#is IQ probability is b
#x>b=95%=0.95
#x=95%=0.95
qnorm(0.95,mean = 100,sd=15,lower.tail =FALSE )

